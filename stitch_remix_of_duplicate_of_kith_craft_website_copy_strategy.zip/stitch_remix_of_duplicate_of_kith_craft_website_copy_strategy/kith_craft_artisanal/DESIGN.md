---
name: Kith Craft Artisanal
colors:
  surface: '#fdf8f8'
  surface-dim: '#ddd9d8'
  surface-bright: '#fdf8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3f2'
  surface-container: '#f1edec'
  surface-container-high: '#ebe7e6'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#444748'
  inverse-surface: '#313030'
  inverse-on-surface: '#f4f0ef'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#5e5e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdb'
  on-secondary-container: '#63635f'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#3a0a00'
  on-tertiary-container: '#c56b4f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e4e2dd'
  secondary-fixed-dim: '#c8c6c2'
  on-secondary-fixed: '#1b1c19'
  on-secondary-fixed-variant: '#474744'
  tertiary-fixed: '#ffdbd0'
  tertiary-fixed-dim: '#ffb59f'
  on-tertiary-fixed: '#3a0a00'
  on-tertiary-fixed-variant: '#793019'
  background: '#fdf8f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
  button:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  section-gap: 120px
---

## Brand & Style

The design system is rooted in the philosophy of "Digital Craftsmanship." It targets a discerning audience that values authenticity, tactile quality, and the story behind the object. The visual language balances the structured precision of a high-end editorial look with the warmth of natural, physical materials.

The style is a fusion of **Elevated Minimalism** and **Tactile Organicism**. It leverages generous white space (the "Canvas") to allow products and content to breathe, while using sharp structural lines and "Clay" accents to provide warmth and focus. The emotional goal is to evoke a sense of quiet luxury, reliability, and human-centric design.

## Colors

The palette is inspired by raw materials: kiln-fired clay, woven straw, and charcoal.

- **Canvas (#F9F7F2):** The primary background color. It is warmer than pure white, reducing eye strain and feeling more like heavy-weight paper or organic fabric.
- **Charcoal (#1A1A1A):** Used for high-contrast elements. This is the "ink" of the design system, providing structural integrity through borders, primary buttons, and headings.
- **Clay (#C86D51):** The primary action accent. It should be used sparingly for critical call-outs, interactive states, and price points to maintain its impact.
- **Bamboo (#E2D7C5):** A functional neutral used for subtle separations. It provides a soft bridge between the Canvas background and the dark text.

## Typography

The typography strategy relies on the contrast between the authoritative, literary feel of **Playfair Display** and the modern, accessible clarity of **Plus Jakarta Sans**.

- **Serif (Playfair Display):** Reserved for editorial moments, storytelling, and hierarchy markers. Use for all headlines to establish a premium tone.
- **Sans (Plus Jakarta Sans):** Used for all functional UI elements, body copy, and navigation. Its soft curves complement the warmth of the color palette while maintaining legibility at small sizes.
- **Uppercase Labels:** Use the `label-caps` style for section headers and small badges to create a "gallery-tag" aesthetic.

## Layout & Spacing

This design system utilizes a **Fluid Grid** with generous, fixed outer margins to maintain the "editorial" feel. 

- **The 8px Rhythm:** All padding and internal spacing should be increments of 8px.
- **Vertical Air:** Section gaps are intentionally large (120px on desktop) to prevent the UI from feeling cluttered or "salesy."
- **Desktop Layout:** A 12-column grid with 24px gutters. Content should generally be centered within a 1280px max-width container.
- **Mobile Layout:** A 4-column grid with 16px gutters. Use full-bleed backgrounds for different sections to create clear visual separation without adding weight.

## Elevation & Depth

To maintain the "authentic" and "tactile" brand tone, this design system avoids heavy shadows and synthetic blurs.

- **Low-Contrast Outlines:** Instead of shadows, use 1px borders in `Bamboo (#E2D7C5)` to define cards and containers.
- **Tonal Layering:** Depth is achieved by placing `Canvas (#F9F7F2)` cards on white backgrounds, or vice versa. 
- **The "Pressed" Effect:** For interactive states (like buttons or cards), use a slight background color shift or a thin 1px inset border rather than a lift/drop shadow. This reinforces the physical, flat-lay aesthetic.
- **Structural Lines:** Use 1px `Charcoal (#1A1A1A)` lines for primary navigation and footer separation to provide a "skeletal" frame for the design.

## Shapes

The shape language is **Soft (0.25rem)**. This subtle rounding prevents the UI from feeling too clinical or aggressive while maintaining the structure of a high-end physical publication.

- **Standard Elements:** Buttons, input fields, and small cards use the default 4px (0.25rem) radius.
- **Image Containers:** Product photography should either be perfectly sharp (0px) to feel like a printed photo or use the Soft (4px) radius to match the UI.
- **Large Cards:** Use `rounded-lg` (8px) for large content sections to provide a gentle, welcoming feel.

## Components

### Buttons
- **Primary:** Solid `Charcoal (#1A1A1A)` background with white text. No shadow. On hover, the background shifts to `Clay (#C86D51)`.
- **Secondary:** Solid `Bamboo (#E2D7C5)` background with `Charcoal (#1A1A1A)` text. Minimalist and grounded.
- **Tertiary/Ghost:** 1px `Charcoal` border with no background.

### Input Fields
- Underlined style or a 4-sided 1px border in `Bamboo`.
- Focus state: Border changes to `Charcoal` with a 1px thickness. No "glow" effect.

### Chips & Badges
- Used for categories or price tags. 
- Style: Solid `Clay (#C86D51)` for alerts/tags, or `Bamboo (#E2D7C5)` for neutral categories.
- Typography: Always `label-caps`.

### Cards
- Background: Pure White or `Canvas`.
- Border: 1px `Bamboo (#E2D7C5)`.
- Padding: Minimum 24px on all sides to maintain the minimalist aesthetic.

### Dividers
- 1px horizontal or vertical lines using `Bamboo`. For high-level section breaks, use `Charcoal` but with a lower opacity (20%).

### Additional Components
- **Product Tiles:** Focus on high-quality imagery with a centered `Playfair Display` title underneath.
- **Breadcrumbs:** Small `label-caps` typography separated by a forward slash (/).